/*
V1.0.1
SimplyCommand.cpp- A library developed for controlling motors easily by passing Servo Objects
Developed by Paramesh Sriram P S
*/
#include "SimplyCommand.h"
#include "Arduino.h"
// This is the function that is used to define your control scheme.
SimplyCommand::SimplyCommand() {
}
void SimplyCommand::defineControlScheme(int numMotors, String motorListName[], int pinList[], String sender, String receiver, String password) {
  senderGlobal = sender;
  receiverGlobal = receiver;
  passwordGlobal = password;
  for (int i = 0; i < numMotors; i++) {
    //Assign values to globalVariables
    motorListNameGlobal[i] = motorListName[i];
    pinListGlobal[i] = pinList[i];
    //Attach the motors
    motorListGlobal[i].attach(pinListGlobal[i]);
  }
  Serial.println("Attaching and configuration complete.");
}
String* SimplyCommand::splitStringIntoArray(String str, char delimiter) {
  int substringCount = 0;
  for (int i = 0; i < str.length(); i++) {
    if (str[i] == delimiter) {
      substringCount++;
    }
    size = substringCount;  //Update the size globally
  }
  String* splitStrings = new String[substringCount + 1];
  int strIndex = 0;
  int splitStringIndex = 0;
  while (strIndex < str.length()) {
    int delimiterIndex = str.indexOf(delimiter, strIndex);
    if (delimiterIndex == -1) {
      splitStrings[splitStringIndex] = str.substring(strIndex);
      splitStringIndex++;
      break;
    }
    splitStrings[splitStringIndex] = str.substring(strIndex, delimiterIndex);
    splitStringIndex++;
    strIndex = delimiterIndex + 1;
  }
  return splitStrings;
}
int SimplyCommand::executeInstruction(String instruction) {
  String* splitArrayWithSpaces = splitStringIntoArray(instruction, instSplit);
  int arrSize = size;
  int ret = 0;
  //These three variables are used to check for authenticity of the communication
  int fromCheck = 0;
  int toCheck = 0;
  int passCheck = 0;
  for (int i = 0; i < arrSize + 1; i++) {
    //  Serial.println(splitArrayWithSpaces[i]);
    if (splitArrayWithSpaces[i].indexOf(':') != -1) {
      String* splitWithColon = splitStringIntoArray(splitArrayWithSpaces[i], valSplit);
      if (splitWithColon[0].indexOf('S') != -1) {
        if (splitWithColon[1].equals(senderGlobal)) {
          //Serial.println("Sender Verified...");
          fromCheck = 1;
        }
      } else if (splitWithColon[0].indexOf('R') != -1) {
        if (splitWithColon[1].equals(receiverGlobal)) {
          // Serial.println("Receiver Verified...");
          toCheck = 1;
        }
      } else if (splitWithColon[0].indexOf('P') != -1) {
        if (splitWithColon[1].equals(passwordGlobal)) {
          //Serial.println("Password Verified...");
          passCheck = 1;
        }
      }
      if ((fromCheck == 1) && (toCheck == 1) && (passCheck == 1)) {
        ret = mapToEngine(splitWithColon[0], splitWithColon[1].toInt());
      } else {
        //Serial.println("VERIFICATION FAILED!!");
      }

      //Serial.println(splitWithColon[0]);
      //Serial.println(splitWithColon[1]);
    }
  }
  return ret;
}


int SimplyCommand::mapToEngine(String name, int value)  //Function used to map the instruction to the respective engines
{
  int ret = 0;
  int counter = 0;
  while (counter < numMotorGlobal + 3) {
    if (name == motorListNameGlobal[counter]) {
      motorListGlobal[counter].write(value);
      /*
      Serial.println("Wrote");
      Serial.println(name);
      Serial.println(value);
      */
      break;
      ret = 1;
    } else {
      ret = -1;
    }
    counter++;
  }
  return ret;
}
void SimplyCommand::alterParameter(char instParam, char motorValSplit)  //Used to alter the delimiters
{
  char instSplit = instParam;
  char valSplit = motorValSplit;
}
void SimplyCommand::setAction(String actionName, String instruction)  //Use this to define actions.
{
  String preAdd = "SET S:" + senderGlobal + " R:" + receiverGlobal + " P:" + passwordGlobal + " ";
  actionNameList[actionIndex] = actionName;
  actionList[actionIndex] = preAdd + instruction;
  actionIndex = actionIndex + 1;
}
void SimplyCommand::callAction(String actionName) {  //Use this to call the action
  int index = 0;
  int conf = 0;
  while (index <= actionIndex) {
    if (actionName.equals(actionNameList[index])) {
      executeInstruction(actionList[index]);
      conf = 1;
    }
    index = index + 1;
  }
  if (conf == 0) {
    Serial.println("ACTION NOT FOUND. PLEASE USE setAction() TO DEFINE IT");
  }
}
void SimplyCommand::printAllActions() { //Use this to print all the available actions.
  int counter = 0;
  while (counter <= actionIndex) {
    Serial.print(actionNameList[counter]);
    Serial.print(' ');
    Serial.print(actionList[counter]);
    Serial.println();
  }
}
void SimplyCommand::doAction(String action) { //Use this to directly give engine commands.
  String preAdd = "SET S:" + senderGlobal + " R:" + receiverGlobal + " P:" + passwordGlobal + " ";
  String command = preAdd + action;
  executeInstruction(command);
}