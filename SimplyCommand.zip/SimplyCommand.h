/*
V1.0.1
SimplyCommand.cpp- A library developed for controlling motors easily by passing Servo Objects
Developed by Paramesh Sriram P S
*/
#include "Arduino.h"
#include "Servo.h"
class SimplyCommand {
public:
  SimplyCommand();
  void defineControlScheme(int numMotors,String motorListName[], int pinList[], String sender, String receiver, String password);
  int executeInstruction(String instruction);
  void alterParameter(char instParam, char motorValSplit);
  void setAction(String actionName, String instruction);
  void callAction(String actionName);
  void printAllActions();
  void doAction(String action);
private:
  int mapToEngine(String name, int value);
  String* splitStringIntoArray(String str, char delimiter);
  String motorListNameGlobal[32];
  Servo motorListGlobal[32];
  int pinListGlobal[32];
  int numMotorGlobal;
  String senderGlobal;
  String receiverGlobal;
  String passwordGlobal;
  int size;
  int globalCounterForMotor = 0;
  String actionNameList[256];
  String actionList[256];
  int actionIndex = 0;
  //These are the default values. Change them using alterParameters if neccessary
  char instSplit = ' ';
  char valSplit = ':';
};